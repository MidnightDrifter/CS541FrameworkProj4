#ifndef OPENGL_GEN_CORE_REM3_0_H
#define OPENGL_GEN_CORE_REM3_0_H

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus*/
#define GL_ALPHA_INTEGER 0x8D97
#define GL_CLAMP_FRAGMENT_COLOR 0x891B
#define GL_CLAMP_VERTEX_COLOR 0x891A



#ifdef __cplusplus
}
#endif /*__cplusplus*/
#endif /*OPENGL_GEN_CORE_REM3_0_H*/
