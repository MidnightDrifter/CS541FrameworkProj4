#ifndef OPENGL_GEN_CORE_REM2_0_HPP
#define OPENGL_GEN_CORE_REM2_0_HPP

#include "_int_load_test.hpp"
namespace gl
{
	enum
	{
		COORD_REPLACE                    = 0x8862,
		MAX_TEXTURE_COORDS               = 0x8871,
		POINT_SPRITE                     = 0x8861,
		VERTEX_PROGRAM_TWO_SIDE          = 0x8643,
	};
	
	namespace _detail
	{
	}
	
	
}
#endif /*OPENGL_GEN_CORE_REM2_0_HPP*/
