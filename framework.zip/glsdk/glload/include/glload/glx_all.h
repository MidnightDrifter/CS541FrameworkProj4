#ifndef GLXWIN_GEN_ALL_H
#define GLXWIN_GEN_ALL_H

#include "_int_glx_type.h"
#include "_int_glx_exts.h"

#endif /*GLXWIN_GEN_ALL_H*/
