#ifndef OPENGL_GEN_1_5_HPP
#define OPENGL_GEN_1_5_HPP

#include "_int_gl_type.hpp"
#include "_int_gl_exts.hpp"

#include "_int_gl_1_0.hpp"
#include "_int_gl_1_1.hpp"
#include "_int_gl_1_2.hpp"
#include "_int_gl_1_3.hpp"
#include "_int_gl_1_4.hpp"
#include "_int_gl_1_5.hpp"
#endif /*OPENGL_GEN_1_5_HPP*/
